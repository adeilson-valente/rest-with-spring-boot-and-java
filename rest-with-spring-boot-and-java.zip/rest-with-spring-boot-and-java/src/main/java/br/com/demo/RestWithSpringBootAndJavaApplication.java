package br.com.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestWithSpringBootAndJavaApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestWithSpringBootAndJavaApplication.class, args);
	}

}
